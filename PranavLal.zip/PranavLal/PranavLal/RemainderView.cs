﻿//////////////////////////////////////////////////////////////////////
// PranavLal           RemainderView                12-01-2019      //
// This program is written to add a new remainder to the database   //
// so during the running time of the application , the database is  //
// accesses frequently to check the events so that even in system   //
// shutdown time we will no lose the data                           //
//////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PranavLal
{
    public partial class RemainderView : Form
    {
        // Below Function calls the database table and loads the value to the screen 
        public RemainderView()
        {
            InitializeComponent();
            SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
            conn.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("SELECT * FROM dbo.PranavRemainder", conn);
            DataTable view1 = new DataTable();
            cmd.Fill(view1);

            dataGridView1.DataSource = view1;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {           

        }

        // Retrun logic to load maintable
        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();

        }
    }
}
