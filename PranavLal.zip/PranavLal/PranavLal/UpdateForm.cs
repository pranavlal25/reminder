﻿//////////////////////////////////////////////////////////////////////
// PranavLal           UpdateForm                   12-01-2019      //
// UpdateForm.cs code handles the update form functionalities       //
// It loads a datagridview by reading the data as table from        //
// database table
//////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PranavLal
{        
    public partial class UpdateForm : Form
    {
       // Update Form is to connect to the database and load teh data TO datagridview1
       // which is then loaded to the screen, from which user can choose the entry he likes
       // update
        public UpdateForm()
        {
            InitializeComponent();
            SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
            conn.Open();

            SqlDataAdapter cmd = new SqlDataAdapter("SELECT * FROM dbo.PranavRemainder", conn);
            DataTable view1 = new DataTable();
            cmd.Fill(view1);

            dataGridView1.DataSource = view1;
             
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {            
           
        }

        // Below button click handles the logic for Return and loads the mainform
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
            
        }
        // Below code handles the deletion row logic from the tables
        // by using the click user can delete the entry as he requires
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;
            dataGridView1.CurrentCell.Selected = true;
            String number = dataGridView1.CurrentRow.Cells[0].Value.ToString();

            DialogResult dialogResult = MessageBox.Show("Are you sure ?","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (dialogResult == DialogResult.Yes)
            {
                
                SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
                conn.Open();
                string query = "DELETE FROM dbo.PranavRemainder WHERE [S.NO] = '" + number + "'";
                SqlCommand Add = new SqlCommand(query, conn);
                Add.ExecuteNonQuery();
                MessageBox.Show("Removed the entry");            
                             

            }
            else if (dialogResult == DialogResult.No)
            {
                return;

            }
        }

        // Below functionality handles the update query logic from screen to the table

        private void button1_Click(object sender, EventArgs e)
        {
            
            dataGridView1.CurrentCell.Selected = true;
            string ValueType = dataGridView1.CurrentCell.ColumnIndex.ToString();

            int ColoumnNumber = Int32.Parse(ValueType);

            if (ColoumnNumber == 0)
            {
                MessageBox.Show("Sorry you can't change the S.NO value, please try deletion instead");
            }

            else
            {                
                SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
                conn.Open();                
                String SNO = dataGridView1.CurrentRow.Cells["S.NO"].Value.ToString();
                String RemainderName = dataGridView1.CurrentRow.Cells["Remainder Name"].Value.ToString();
                String Location      = dataGridView1.CurrentRow.Cells["Location"].Value.ToString();
                String Date         = dataGridView1.CurrentRow.Cells["Date"].Value.ToString();
                DateTime dt = Convert.ToDateTime(Date);
                
                // Lets convert the date format to YYYY/MM/DD
                String tempdate = dt.ToString("yyyy/MM/dd");

                string query = "UPDATE dbo.PranavRemainder SET [S.NO] =  '" + SNO + "' , [Remainder Name] = '" + RemainderName + "', Location = '" + Location + "',Date ='" + tempdate + "' WHERE [S.NO] = '"+SNO+"' ";

                SqlCommand Add = new SqlCommand(query, conn);

                Add.ExecuteNonQuery();

                MessageBox.Show("Updated the remainder successfully");                
                return;

            }
        }
    }
}
