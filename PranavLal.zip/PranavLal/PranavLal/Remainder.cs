﻿//////////////////////////////////////////////////////////////////////
// PranavLal           Remainder.CS                   -01-2019      //
// Remainder.CS is unused at the minute but can be used later on    //
//////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PranavLal
{
     // Below class is unused at the minutes but can be added with logic if require
    class Remainder
    {
        String[] EventDate  = new string[1000];
        String[] DataString = new string[1000];
        public int i;
        public int TableRead = 0;
        // Lets make below function as the main function loop to keep checking the remainder array
        public void MainLoop()
        {         
           
        }

       

    }
}
