﻿//////////////////////////////////////////////////////////////////////
// PranavLal           Form1                        12-01-2019      //
// This program is written to add a new remainder to the database   //
// so during the running time of the application , the database is  //
// read for once and stored in an array, array date and time is     //
// compared against current system date and time and if the time    //
// and date matches , program puts up a message box                 //
//////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PranavLal
{
   
    public partial class Form1 : Form
    {
        
        public int number;
        public String RemainderName;
        public String RemainderLocation;
        public DateTime TimeEvent;
        public DateTime CurrentTime;
        public int i;
        public int TableRead = 0;
        String[] EventDate = new string[1000];
        String[] DataString = new string[1000];
        public static int NumberofTimes;

        // Belos function intializes the form and calls fore the database read function
        public Form1()
        {
            InitializeComponent();

            if (NumberofTimes == 0)
            {
                this.Shown += ExecuteCall;
                NumberofTimes = NumberofTimes + 1;
            }

            else

            {


            }

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            
           
            
        }

        // Below function reads the database table dbo.PranvavRemainder and loads in to array 
        // With various coloumns such as SNO, RemainderName,Location and Value
        // Value is the date field which we iterate against the current system date and time
        // and if match founds then a message box is displayed.
        public void ExecuteCall(object sender, EventArgs e)
        {
             
            while (TableRead == 0)
            {
                SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.PranavRemainder", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int Displaying;
                    String SNO = reader["S.NO"].ToString();
                    String RemainderName = reader["Remainder Name"].ToString();
                    String Location = reader["Location"].ToString();
                    String Value = reader["Date"].ToString();
                    DateTime dt = Convert.ToDateTime(Value);
                    EventDate[i] = Value;
                    String TimesNow = DateTime.Now.ToString("dd/MM/yyyy");
                    String CompareTime = dt.ToString("dd/MM/yyyy");
                    DataString[i] = " You have got an appointment " + RemainderName + " at " + Location + " on " + CompareTime;                   
                   
                    if (TimesNow == CompareTime)
                    {
                        System.Threading.Thread.Sleep(2);
                        MessageBox.Show(DataString[i]);
                        
                    }

                    i = i + 1;
                }

                TableRead = 1;

            }

            this.Activated -= Form1_Load;
            return;
        }

        // Button logic to load View data grid table from databse
        public void Create_Click(object sender, EventArgs e)
        {
                       
            this.Hide();          
            RemainderView f3 = new RemainderView();
            f3.Show();          

        }

        // Butoon click to connec to database and load form AddNewREmainder
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
            conn.Open();
            this.Hide();
            AddNewRemainder f2 = new AddNewRemainder();
            f2.Show();
            
        }

        // Below code triggers Update form the main code

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateForm f4 = new UpdateForm();
            f4.Show();
        }

       //Remainder function as CS but not executed at the  minutes.
        static void CallingFunction()
        {
            Remainder r2 = new Remainder();
            r2.MainLoop();     
                       
        }
    }
}
