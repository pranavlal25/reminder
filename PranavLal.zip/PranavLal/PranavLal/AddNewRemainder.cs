﻿//////////////////////////////////////////////////////////////////////
// PranavLal           AddNewRemainder              12-01-2019      //
// This program is written to add a new remainder to the database   //
// so during the running time of the application , the database is  //
// accesses frequently to check the events so that even in system   //
// shutdown time we will no lose the data                           //
//////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PranavLal
{
    public partial class AddNewRemainder : Form
    {
        
        public int number;
        public String RemainderName;
        public String RemainderLocation;
        public DateTime TimeEvent;
        public DateTime CurrentTime;

        public AddNewRemainder()
        {
            InitializeComponent();
            
        }

        // Below logic handles the return from the curent form to mainform
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        // Logic to add the remainder name, reminder location and the 
        // date string
        private void button1_Click(object sender, EventArgs e)
        {
            
            if(textBox1.Text == "")
            {
                MessageBox.Show("Remainder name is empty please add a name");
                return;
            }

            else

            {
                RemainderName = textBox1.Text;
            }

            
            if (textBox2.Text == "")
            {
                 MessageBox.Show("Remainder Location is empty please add a Location");
                 return;
            }

            else

            {
                RemainderLocation = textBox2.Text;
            }

            DateTime result = dateTimePicker1.Value;

            this.Text = result.ToString("yyyy-MM-dd");
            
            
            //Below function will execute the query to load data in to teh table
            AddValue();
           
        }
        // Below function calls the insert query and adds the values from screen to database
        // table
        public void AddValue()
        {
            
             SqlConnection conn = new SqlConnection("Server=.\\SQLEXPRESS;Database=VaravuChilavu;Integrated Security=true");
             conn.Open();

            // Now lets do an add operation so the remainder value goes in to the database
            // before that we need to get the s.no to add the values so we will do a quick
            // read operation and based on that new row number can be se
             SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM dbo.PranavRemainder", conn);
             Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
             number = count + 1;
            
             string query = "INSERT INTO dbo.PranavRemainder([S.NO],[Remainder Name],Location,Date) VALUES ('" +number+"','"+RemainderName+"', '"+RemainderLocation+"','"+this.Text+"')";           

             SqlCommand Add = new SqlCommand(query, conn);             

             Add.ExecuteNonQuery();

             MessageBox.Show("Added the remainder successfully");
             return;
                                 
            
        }
    }
}
